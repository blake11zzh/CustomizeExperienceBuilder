import { React, type AllWidgetProps } from 'jimu-core'

const Widget = (props: AllWidgetProps<any>) => {
  return <div className="widget-starter jimu-widget">This is your starter widget!</div>
}

export default Widget

